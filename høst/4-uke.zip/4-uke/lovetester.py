navn1 = input("hva er det første navnet?")
navn2 = input("hva er det andre navnet?")
bosted1 = input("hvor bor navn1")
bosted2 = input("hvor bor navn2")
navn1 = navn1.lower()
navn2 = navn2.lower()

lengde1 = len(navn1)
lengde2 = len(navn2)

første1 = navn1[0]
første2 = navn2[0]


if lengde1 == lengde2:
    match = 60
elif første1 == første2:
    match = 40
else: 
    match = 15

if bosted1 == bosted2:
    match = match *1.5

print(match,"%")