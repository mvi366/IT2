import pygame
import random
from person import Person
from eple1 import Eple1
from eple2 import Eple2
from eple3 import Eple3

# 1. Oppsett
pygame.init()
BREDDE = 600
HOYDE = 600
FPS = 60
vindu = pygame.display.set_mode((BREDDE, HOYDE))
klokke = pygame.time.Clock()

spiller = Person(BREDDE, HOYDE)
epler = [Eple1(BREDDE), Eple2(BREDDE), Eple3(BREDDE)]


for eple in epler:
    eple.x = random.randint(0, BREDDE - eple.ramme.width)
    eple.y = random.randint(-HOYDE, - eple.ramme.height)
    eple.fallhastighet = random.randint(1, 5)

while True:
    # 2. Håndter input
    for hendelse in pygame.event.get():
        if hendelse.type == pygame.QUIT:
            pygame.quit()
            raise SystemExit
        
    taster = pygame.key.get_pressed()
    if taster [pygame.K_LEFT]:
        spiller.flytt(-1)
    if taster[pygame.K_RIGHT]:
        spiller.flytt(1)
        
    # 3. Oppdater spill
    for eple in epler:
        eple.fall(HOYDE)

    # 4. Tegn
    vindu.fill("black")
    spiller.tegn(vindu)
    for eple in epler:
        eple.tegn(vindu)

    pygame.display.flip()
    klokke.tick(FPS)