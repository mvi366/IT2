import random
from figur import Figur

class Eple2(Figur):
    def __init__(self, vindu_bredde: int) -> None:
        super().__init__("bilder/eple2.png", 0.1)
        self.verdi = 2
        # flytter ballen til startposisjonen
        self.rect.left = random.randint(0, vindu_bredde - self.rect.width)
        self.rect.top = 0
        self.ny_plassering(vindu_bredde)


    def fall(self, vindu_høyde: int):
        if self.rect.top > vindu_høyde:
            self.rect.y = 0
        self.rect.y += 1
    def ny_plassering(self, vindu_bredde: int):
        self.rect.centerx = random.randint(0, vindu_bredde)
        self.rect.top = 0
