import pygame
import random
from person import Person
from eple1 import Eple1
from eple2 import Eple2
from eple3 import Eple3

# 1. Oppsett
pygame.init()
BREDDE = 1000
HOYDE = 600
FPS = 60
vindu = pygame.display.set_mode((BREDDE, HOYDE))
klokke = pygame.time.Clock()

spiller = Person(BREDDE, HOYDE)
epler = [Eple1(BREDDE), Eple2(BREDDE), Eple3(BREDDE)]


bakgrunn = pygame.image.load("bilder/eplebakgrunn.jpeg").convert_alpha()
def tegn_bakgrunn():
    skalerbakgrunn = pygame.transform.scale(bakgrunn, (BREDDE, HOYDE))
    vindu.blit(skalerbakgrunn, (0,0))

font = pygame.font.SysFont("sans", 30)
poeng = 0

def poengfunksjon():
    poeng_text = font.render("Poeng: " + str(poeng), True, (255, 255, 255))
    vindu.blit(poeng_text, (10, 10))
    




while True:
    # 2. Håndter input
    for hendelse in pygame.event.get():
        if hendelse.type == pygame.QUIT:
            pygame.quit()
            raise SystemExit

    taster = pygame.key.get_pressed()
    if taster[pygame.K_LEFT]:
        spiller.flytt(-2)
    if taster[pygame.K_RIGHT]:
        spiller.flytt(2)

    
    

    # 3. Oppdater spill
    for eple in epler:
        eple.fall(HOYDE)

    for eple in epler:
        if spiller.kollisjon(eple.rect):
            
            if eple.rect.centery > spiller.rect.centery - 50: 
                poeng += eple.verdi

                eple.ny_plassering(HOYDE)

    # 4. Tegn
    tegn_bakgrunn()
    poengfunksjon()
    spiller.tegn(vindu)
    for eple in epler:
        eple.tegn(vindu)

    
    pygame.display.flip()
    klokke.tick(FPS)