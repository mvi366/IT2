# Spillprosjekt

Et skikkelig kult politikerspill. Laget med Pygame.

To do:
- [x] Skisse
- [ ] Klasser
- [ ] Bavegelse
- [ ] Miste liv/dø
