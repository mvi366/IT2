from random import*

terningkast = randint(1,6)
print(terningkast)


