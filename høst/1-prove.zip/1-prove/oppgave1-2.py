from random import*

terning1 = randint(1,6)
terning2 = randint(1,6)
terning3 = randint(1,6)
terning4 = randint(1,6)
terning5 = randint(1,6)

print("resultatet fra terning 1 =", terning1,"resultatet fra terning 2=", terning2,"resultatet fra terning 3 =", terning3,"resultatet fra terning 4 =", terning4,"resultatet fra terning 5 =", terning5, )


